<embed src="1.mp3" hidden="true" autostart="true" loop="false" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr >
    <td width="10%" align="center" bgcolor="#D6D6D6" ><strong>ສາຂາ</strong></td>
    <td width="15%" align="center" bgcolor="#D6D6D6"><strong>ເລືອກ</strong></td>
    <td width="8%" align="center" bgcolor="#D6D6D6"><strong>ປະຕູ</strong></td>
    <td width="8%" align="center" bgcolor="#D6D6D6"><strong>ລາຄາ</strong></td>
    <td width="10%" align="center" bgcolor="#D6D6D6"><strong>ຍອດສ່ຽງ</strong></td>
    <td width="8%" align="center" bgcolor="#D6D6D6"><strong>ເວລາ</strong></td>
    <td width="10%" align="center" bgcolor="#D6D6D6"><strong>ພະນັກງານ</strong></td>
    <td width="10%" align="center" bgcolor="#D6D6D6"><strong>ID</strong></td>
  
  </tr>
</table>