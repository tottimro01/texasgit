<?php
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0;URL=../index.php'>";
?>