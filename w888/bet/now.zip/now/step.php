<? ob_start(); if (!isset($_SESSION)) { session_start(); } 

include "../data/soccer_datastep_live.php";
?>